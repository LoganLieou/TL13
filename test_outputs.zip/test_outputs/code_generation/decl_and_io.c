#include <stdio.h>
int main(void) {
	int X;
	int Y;
	int Z;
	scanf("%d", &X);
	printf("%d", X);
}
