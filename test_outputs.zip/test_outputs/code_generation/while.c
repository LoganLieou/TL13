#include <stdio.h>
int main(void) {
	int X;
	while(X > 1) {
		X = X + 1;
	}
}
