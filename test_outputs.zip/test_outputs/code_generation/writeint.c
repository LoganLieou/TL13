#include <stdio.h>
int main(void) {
	int X;
	X = 5;
	printf("%d", X);
}
