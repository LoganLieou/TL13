#include <stdio.h>
int main(void) {
	int X;
	if (X > 5) {
		X = X + 2;
	}
	else {
		X = X - 2;
	}
}
